'''
Created on Nov 4, 2012

@author: Boris Jurosevic
         Assignment: Knights Tour
'''
from knights_tour import KnightsTour
from tile import Tile

def main():

    tour = KnightsTour()
    tour.saberi()
    
    input("\nThank you for visiting Knights Tour!")
    



if __name__ == '__main__':
    main()